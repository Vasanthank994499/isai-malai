# Music catalogue rights status

**Status: not connected.** Isai Malai currently includes no commercial recordings, music files, catalogue API credentials, or licence grant.

Before offering online streams, the service owner must select a music provider and obtain the permissions and commercial terms needed for the intended app, users, monetization model, territories, and playback modes. The source code and Android wrapper do not grant rights to recordings or compositions. Do not upload or publish songs unless the applicable rights permit that use.

The present prototype plays only files a listener selects locally. It does not upload those files and does not determine whether they are Tamil or whether the listener is authorized to play them.
