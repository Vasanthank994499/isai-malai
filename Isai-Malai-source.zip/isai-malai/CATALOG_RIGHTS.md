# Music catalog and rights status

Isai Malai searches the public Internet Archive Advanced Search API for audio records with Tamil-related metadata. Results are restricted to items whose metadata declares CC BY 4.0, CC BY-SA 4.0, CC0 1.0, or Public Domain Mark 1.0. The app checks each item file list and exposes it only when a browser-playable FLAC, WAV, AIFF, or explicitly identified ALAC file is available. Playback streams that selected source directly from Internet Archive; the app does not rehost it or fall back to a lossy file.

File formats and rights are contributor-supplied information. A FLAC, WAV, AIFF, or ALAC label does not prove that the original master was lossless, and Archive.org does not guarantee copyright status or the accuracy of uploader claims. Inspect each source item and confirm the rights and terms for your intended use. This integration does not grant a license to commercial recordings, artwork, or compositions.

The results are not a complete Tamil music catalog. Search matches can include spoken-word recordings, books, or other audio; Tamil language and song status may not be verified. Search may omit records when their available files are lossy or the source format is unsupported by the browser.

Local-file playback accepts supported lossless formats only. Those files remain in the browser and are not uploaded.

The Isai Malai application source code is licensed under GNU GPL version 3; see [LICENSE](LICENSE). This software license is separate from all music and artwork rights.
