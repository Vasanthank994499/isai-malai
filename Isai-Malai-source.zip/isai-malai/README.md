# Isai Malai

Isai Malai is a Tamil-only music listening interface with original branding, a responsive streaming-style layout, browser playback, and an installable web app.

## What is ready

- Browse Tamil music categories and search tracks selected from this device.
- Play, pause, skip, seek, change volume, repeat, shuffle, and save imported audio.
- Install the website from Chrome on supported devices as a home-screen web app. The static page and interface shell are cached for offline opening.
- Publish the website with the included GitHub Pages workflow after the source is in a GitHub repository and Pages is enabled.
- Build an Android debug APK from the included Android WebView project. The manually triggered GitHub Actions workflow uploads a debug APK after the owner explicitly accepts the Android SDK license agreements.

## Music catalogue and rights

No commercial catalogue, Spotify account, or music licence is connected. This build plays files selected by the listener and does not upload them or automatically verify that they are Tamil. The included application code grants no rights to third-party music. A public streaming catalogue needs a provider and written rights for the catalogue and launch territories.

See [CATALOG_RIGHTS.md](CATALOG_RIGHTS.md) before connecting a music provider.

## Android APK

The android/ folder contains the native wrapper. It packages the web app as local assets and opens Android's file picker for listener-selected audio. It is not signed for Google Play release. The GitHub Actions workflow builds a debug APK; a signed release needs the owner's signing key and release secrets.

To build locally, install Android Studio with Android SDK 35 and JDK 17, then open android/ in Android Studio or run gradle assembleDebug from that directory.

## Run the web version

Serve dist/ over localhost or a static HTTPS host. No build step or package installation is needed.
