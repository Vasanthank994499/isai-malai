# Isai Malai

Isai Malai is a Tamil-only listening site and Android WebView app with a green mobile player, search, saved tracks, a playback queue, and local audio import.

## Playback

- Search the Internet Archive for Tamil-tagged audio records. Search results are checked for browser-playable FLAC, WAV, AIFF, or explicitly identified ALAC source files.
- Lossy files are never used as a fallback. The player identifies the selected file format, but uploader metadata cannot prove that the original recording master was lossless.
- Play lossless-format local audio selected on the device. The app does not upload local files.
- Use play, pause, skip, seek, volume, repeat, shuffle, saved tracks, and the expanded now-playing queue.
- Install the site from Chrome on supported devices. The interface and license file are cached for offline opening; Archive.org search and streaming require an internet connection.
- Build an Android debug APK from the included WebView project. It has internet access for Archive.org API and audio requests.

## Catalog and rights

Archive.org is a contributor-uploaded collection, not a complete Tamil songs catalog. Search results may include spoken-word recordings or other audio. The item's declared license and file metadata are uploader-provided and not independently verified. A lossless file format does not prove the original master was lossless. Inspect each item page and confirm rights for your intended use. This integration does not grant a license to commercial recordings or compositions.

See [CATALOG_RIGHTS.md](CATALOG_RIGHTS.md) for the current source and rights limits.

## Reference and source license

The mobile player arrangement was informed by the user-supplied BitChord APK. No BitChord source code, logo, or recordings are included. At the user's request, Isai Malai source code is licensed under the GNU GPL version 3. See [LICENSE](LICENSE). This software license does not license music recordings, artwork, or compositions.

## Android APK

The `android/` folder contains the WebView wrapper. It packages `dist/` as local assets and opens Android's file picker for supported lossless formats. The debug APK is for installation and testing and is not signed for Google Play release.

To build locally, open `android/` in Android Studio with Android SDK Platform 35 and JDK 17, or run `gradle assembleDebug` from that directory.

## Run the web version

Serve `dist/` over localhost or static HTTPS hosting. No package installation or build step is required.
