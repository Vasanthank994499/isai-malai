# Isai Malai

Isai Malai is a Tamil music web player and Android WebView project. It has Tamil song and movie discovery through Apple Music India metadata, local search by song, artist and album, recent searches with cached results and seven-at-a-time loading, a queue, liked songs, 30-second previews, artwork, synced LRC lyrics, an in-app floating player, media controls, a device profile, categorized settings, and an audio pipeline view.

## Add music

Import FLAC, WAV, AIFF, or identified ALAC files. Audio is kept in the browser's IndexedDB when storage is available. Lyrics can be added to the current track with an `.lrc` file; artwork can be added from the player menu.

Settings can import a JSON catalogue containing HTTPS URLs for licensed lossless files:

```json
{"rightsConfirmed":true,"tracks":[{"title":"Example Tamil track","artist":"Artist","album":"Album","url":"https://your-licensed-host.example/song.flac","format":"FLAC","artwork":"https://your-licensed-host.example/cover.jpg","lyrics":"[00:00.00]Optional licensed lyrics"}]}
```

The catalogue owner must have the recording, composition, artwork, and lyrics rights needed for public streaming. The app includes no commercial music catalogue or cloud account service. File format labels do not verify original master quality.

## Run and build

Serve `dist/` from static HTTPS hosting. The site can be installed as a PWA. The `android/` directory packages `dist/` into a debug APK. It requires JDK 17, Android SDK Platform 35, and Gradle 8.7. The debug APK is not signed for Play Store release.

The app source is GPL-3.0 under [LICENSE](LICENSE). This software license does not grant rights to any music or artwork.

## Audio information and reference

The audio pipeline screen reports source and file fields available to a browser. Decoder, resampler and physical output details are unavailable through WebView and are shown as unknown. Local FLAC/WAV/AIFF/ALAC import uses container or codec checks; this does not prove the source master is lossless. The BitChord APK and its published GPL source were used as workflow references; Isai Malai does not include BitChord code, branding, music data, credentials, or SDK integrations. See `REFERENCE.md` for the feature mapping and limitations.

## Public search

Search sends the typed query to the iTunes Search API for the India storefront and displays Tamil genre song metadata with links that open in Apple Music. Movie-title matches are retained when album genre tags are missing. Artwork and lyrics can be added to tracks the catalogue owner is authorized to stream. Results are a discoverable subset of that catalogue; they are not every Tamil recording. The app does not play or copy Apple preview files. Full-length playback within Isai Malai works only for your own imported files or HTTPS streams licensed for this site.
