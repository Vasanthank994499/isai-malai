# BitChord reference analysis and Isai Malai mapping

Reference sources: the supplied `BitChord.apk`, the public [BitChord source repository](https://github.com/kushagrasinghx/BitChord), and its locally inspected source at `reference/BitChord/`.

## Scope and evidence

REA 6.5.0 `inspect-artifact` inventoried the APK as a ZIP/APK package. Its observed root SHA-256 is `8463f32356301ddb6bacb3177977cfd5a439782c7cad27dceb9de9c3f7ac56c3`; the artifact graph has 569 nodes, 644 occurrences, and 643 edges, with complete coverage of container entries. This inventory does not execute the app or reveal method behavior. REA's `inspect-android-package` was unavailable because this environment has no caller-supplied `jadx-headless-mcp 0.7.1` JAR; the skill says REA does not download or install that prerequisite. The REA MCP server is also not connected to this session. The workflow findings below therefore come from the public source tree, not decompiled APK code or a runtime trace.

The inspected source snapshot is commit `edc1e6f` (2026-10-17). Its app source is licensed under GPL-3.0. That licence covers code; it does not grant rights to music recordings, lyrics, artwork, or third-party catalogues.

## What the source shows

### Search and responsive placement

The Android Search tab uses a `SearchField` in the frosted top bar beside the account photo. The results screen keeps filters and results below that bar, with top padding to clear the system inset and bar. Search includes YouTube Music, local files, and optional add-on sources; it also has search history, suggestions, and paginated results. The ViewModel keeps search results cached and has separate short-debounced suggestion and typeahead flows.

Isai Malai's mobile search field lives in its sticky header. I moved the mobile header contents down by 5 CSS pixels; the desktop layout is unchanged. The same responsive web UI is packaged inside the Android WebView.

### Streaming and source selection

The source contract has separate `search()` and `stream()` operations. The source registry includes user-configured add-ons/modules, JioSaavn, and YouTube Music. `SourceResolver` applies the selected connection quality ceiling, asks enabled sources in priority order, and can fall back when a source has no usable stream. If lossless is selected, it can try a source that advertises lossless support for the same track before falling back. The source code documents YouTube Music as lossy Opus and JioSaavn as lossy AAC/MP4 (up to 320 kbps).

### Lossless audio

There is no lossy-to-lossless converter in the reviewed flow. A lossless request selects an actual FLAC/ALAC-capable source rendition; it does not make AAC or Opus lossless. The supplied screenshot also shows a JioSaavn AAC stream at 320 kbps, which is lossy. BitChord's README describes FLAC/ALAC from configured module sources and YouTube Music as a fallback, not a converter that restores discarded audio data.

### Lyrics, artwork, and speed

The source includes embedded lyrics and multiple lyrics providers; it tracks provider results and displays synchronized lyrics when available. Artwork is loaded with tracks and can drive the player theme. The speed-related path combines cached search results with short-debounced suggestions/typeahead. Playback/source resolution is separate from search, so quick UI response does not guarantee that every provider returns a playable stream quickly.

### Settings and platform boundary

`SettingsSheet.kt` groups settings under Audio quality, Downloads, Playback, Appearance, Performance, Local music, Storage, Your data, Miscellaneous, Language, and Advanced options. The source includes network-specific quality limits, download quality, sleep timer, playback controls, appearance/performance choices, and integrations. Some features depend on Android-native services or configured providers. Isai Malai's WebView wrapper cannot truthfully expose native decoder/DAC state or reproduce every BitChord integration without equivalent native implementation and provider credentials.

## Isai Malai implementation

Isai Malai keeps its own original player and branding. This update only lowers the mobile sticky-header/search row slightly; it does not copy BitChord code or claim unsupported lossless conversion. The app's GPL-3.0 license remains in place. Full-length online streaming still requires audio URLs from a catalogue licensed for this service.
