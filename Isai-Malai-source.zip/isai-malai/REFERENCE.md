# BitChord reference analysis and Isai Malai mapping

Reference artifact: user supplied BitChord.apk. Published source: https://github.com/kushagrasinghx/BitChord . Static APK package inspection confirmed Android dex/native components and model assets. The configured REA MCP command was unavailable during this session, so this is not a complete REA decompilation or dynamic trace.

The supplied screenshot shows JioSaavn AAC, 320 kbps, 44.1 kHz stereo with an Android AAC decoder and AudioTrack output. This is lossy audio. A BitChord setting or provider claim does not make this example lossless.

| BitChord workflow | Isai Malai implementation | Limit |
| --- | --- | --- |
| Home, Search, Library, Player | Green themed desktop and mobile web player | Original UI, not a pixel copy |
| Search filters and history | Songs, artists, albums and recent queries; Apple Music India metadata discovery | Public results open in Apple Music; in-site full playback needs licensed audio |
| Account | Device profile | No cloud OAuth until a provider and backend are configured |
| Audio quality and pipeline | File signature checks, source format, sample rate/bit depth where parsed | WebView cannot inspect native decoder, resampler or DAC |
| Playback | Queue, shuffle, repeat, speed, auto next, sleep timer, screen wake request | Browser and OS support vary |
| Lyrics and artwork | Imported LRC lyrics and image per track | Requires supplied rights cleared data |
| Downloads and storage | Device local audio import in IndexedDB | No third party downloads or sync |
| Sources | Rights confirmed catalogue JSON with HTTPS URLs | No commercial catalogue bundled |

Settings categories in the published BitChord source include Account & Integrations, Audio Quality, Downloads, Playback, Appearance, Performance, Local Music, Storage, Your Data, Miscellaneous, Language and Advanced. Isai Malai exposes controls only where the current web/Android wrapper can implement them truthfully. Native USB DAC, output precision, Dolby Atmos, scrobbling, source modules, Google login, platform downloads, native EQ and shared account data require their own integrations and implementation.

The source code license (GPL-3.0) covers this application code; it grants no licence to the recordings, compositions, lyrics, artwork, or provider catalogues.
