# Isai Malai Android wrapper

This WebView wrapper packages the `../dist/` music player as Android assets. It opens Android's file picker for local lossless audio, lyrics, artwork, and licensed catalogue JSON. Local files stay on the device. HTTPS catalogue audio requires internet access.

Build with JDK 17, Android SDK Platform 35, Android Gradle Plugin 8.6.1, and Gradle 8.7 or newer. Run `gradle assembleDebug` from this directory. The resulting debug APK is for testing; a Play Store release must be signed by the app owner.

The app source is GPL-3.0 under [../LICENSE](../LICENSE). This does not grant music, artwork, or lyrics rights.
