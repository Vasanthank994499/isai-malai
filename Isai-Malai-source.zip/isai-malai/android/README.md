# Isai Malai Android wrapper

This Android WebView wrapper loads `../dist/` as local app assets, supports Android's audio file picker, and uses the internet permission to search Archive.org and stream eligible source files. Local audio stays on the device. The APK contains no bundled commercial recordings.

The app only plays browser-supported FLAC, WAV, AIFF, or clearly identified ALAC formats. Lossy fallback is disabled. A file format label cannot verify the quality of the original recording master, and Archive.org contributor metadata should be checked against each item page.

Build with JDK 17, Android SDK Platform 35, Android Gradle Plugin 8.6.1, and Gradle 8.7 or newer. Running `gradle assembleDebug` from this folder copies `dist/` into the APK before compiling.

The debug APK is for installation and testing. A Play Store release must be signed by the app owner. The Isai Malai source code is licensed under GNU GPL version 3; see [../LICENSE](../LICENSE). That software license does not grant rights to music recordings, artwork, or compositions.
