# Isai Malai Android wrapper

This Android WebView wrapper loads ../dist/ into local app assets and supports the system audio file picker. Build with JDK 17, Android SDK Platform 35, Android Gradle Plugin 8.6.1, and Gradle 8.7 or newer. Running gradle assembleDebug from this folder copies dist/ into the APK before compiling.

The resulting debug APK is for installation/testing. A Play Store release must be signed by the app owner. Music catalogue rights are not included.
